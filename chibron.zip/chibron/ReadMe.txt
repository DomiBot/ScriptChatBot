===============================================================================
 Name: 		Welcome Announcer for Streamlabs Bot
 Version: 	1.2.8
 Creator: 	Bare7a
 Website:	https://github.com/Bare7a/Streamlabs-Chatbot-Scripts
===============================================================================
 - Enable/Disable using the command when the stream is offline
 - Enable/Disable cooldown / user cooldown
 - Enable/Disable cooldown / user cooldown messages
 - Customisable trigger words
 - Customisable permissions for trigger
 - Customisable volume power
 - Customisable cooldown / user cooldown timers 
 - Customisable response messages
===============================================================================
